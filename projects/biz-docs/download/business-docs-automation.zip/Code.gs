/**
 * ระบบสร้างเอกสารธุรกิจอัตโนมัติ (ใบเสนอราคา / ใบแจ้งหนี้ / ใบเสร็จรับเงิน)
 * ----------------------------------------------------------------
 * วิธีติดตั้ง:
 * 1. เปิดไฟล์ Google Sheets นี้ > เมนู Extensions > Apps Script
 * 2. ลบโค้ดตัวอย่างในไฟล์ Code.gs เดิม แล้ววางโค้ดทั้งหมดนี้แทน
 * 3. กด Save (ไอคอนแผ่นดิสก์) ตั้งชื่อโปรเจกต์ตามต้องการ
 * 4. กลับมาที่ Google Sheets แล้ว Reload หน้าเว็บ 1 ครั้ง
 * 5. จะเห็นเมนูใหม่ชื่อ "เอกสารธุรกิจ" ขึ้นแถบเมนูด้านบน
 * 6. คลิกเมนู "เอกสารธุรกิจ" > "ตั้งค่าเริ่มต้น (รันครั้งแรก)" 1 ครั้ง
 *    (ระบบจะขอสิทธิ์เข้าถึง Drive/Sheets — กด Allow ได้ปลอดภัย เพราะสคริปต์นี้ทำงาน
 *     เฉพาะในไฟล์นี้และโฟลเดอร์ที่สร้างขึ้นเองเท่านั้น)
 * 7. กรอกข้อมูลกิจการในชีท Settings ให้ครบ
 * 8. เริ่มใช้งานได้ที่ชีท "New Document"
 */

const SHEET_NAMES = {
  SETTINGS: 'Settings',
  CLIENTS: 'Clients',
  NEW_DOC: 'New Document',
  QUOTATION_TPL: 'Quotation_Template',
  INVOICE_TPL: 'Invoice_Template',
  RECEIPT_TPL: 'Receipt_Template',
  QUOTATIONS: 'Quotations',
  INVOICES: 'Invoices',
  RECEIPTS: 'Receipts',
  DASHBOARD: 'Dashboard',
};

const DOC_TYPE = {
  QUOTATION: 'ใบเสนอราคา',
  INVOICE: 'ใบแจ้งหนี้',
  RECEIPT: 'ใบเสร็จรับเงิน',
};

// ------------------------------------------------------------------
// Menu
// ------------------------------------------------------------------
function onOpen() {
  SpreadsheetApp.getUi()
    .createMenu('เอกสารธุรกิจ')
    .addItem('สร้างเอกสาร PDF', 'generateDocument')
    .addSeparator()
    .addItem('ตั้งค่าเริ่มต้น (รันครั้งแรก)', 'initSetup')
    .addToUi();
}

// ------------------------------------------------------------------
// First-time setup: create the Drive folder structure
// ------------------------------------------------------------------
function initSetup() {
  const ss = SpreadsheetApp.getActiveSpreadsheet();
  const settings = ss.getSheetByName(SHEET_NAMES.SETTINGS);
  let folderId = settings.getRange('B22').getValue();
  let folder;
  if (folderId) {
    try {
      folder = DriveApp.getFolderById(folderId);
    } catch (e) {
      folder = null;
    }
  }
  if (!folder) {
    folder = DriveApp.createFolder('เอกสารธุรกิจ - ' + ss.getName());
    settings.getRange('B22').setValue(folder.getId());
  }
  ['ใบเสนอราคา', 'ใบแจ้งหนี้', 'ใบเสร็จรับเงิน'].forEach(function (name) {
    const it = folder.getFoldersByName(name);
    if (!it.hasNext()) folder.createFolder(name);
  });
  SpreadsheetApp.getUi().alert('ตั้งค่าเสร็จเรียบร้อย\nโฟลเดอร์เก็บ PDF: ' + folder.getUrl());
}

// ------------------------------------------------------------------
// Helpers
// ------------------------------------------------------------------
function getSettingsSheet_() {
  return SpreadsheetApp.getActiveSpreadsheet().getSheetByName(SHEET_NAMES.SETTINGS);
}

function pad3_(n) {
  return ('000' + n).slice(-3);
}

/** Returns { docNo, counterRow } and increments the counter in Settings. */
function nextDocNumber_(type) {
  const s = getSettingsSheet_();
  const year = s.getRange('B17').getValue() || new Date().getFullYear();
  let counterCell, prefix;
  if (type === DOC_TYPE.QUOTATION) { counterCell = 'B18'; prefix = 'QT'; }
  else if (type === DOC_TYPE.INVOICE) { counterCell = 'B19'; prefix = 'INV'; }
  else { counterCell = 'B20'; prefix = 'RCP'; }
  const current = s.getRange(counterCell).getValue() || 1;
  const docNo = prefix + '-' + year + '-' + pad3_(current);
  s.getRange(counterCell).setValue(current + 1);
  return docNo;
}

function findClientRow_(clientName) {
  const sh = SpreadsheetApp.getActiveSpreadsheet().getSheetByName(SHEET_NAMES.CLIENTS);
  const data = sh.getRange(3, 1, 60, 5).getValues();
  for (let i = 0; i < data.length; i++) {
    if (data[i][0] === clientName) {
      return { name: data[i][0], address: data[i][1], phone: data[i][2], email: data[i][3], taxId: data[i][4] };
    }
  }
  return null;
}

/** Simple Thai number-to-text (BAHTTEXT equivalent), written by script for
 *  full compatibility (Google Sheets' native BAHTTEXT also works if preferred). */
function bahtText_(amount) {
  const digit = ['ศูนย์', 'หนึ่ง', 'สอง', 'สาม', 'สี่', 'ห้า', 'หก', 'เจ็ด', 'แปด', 'เก้า'];
  const place = ['', 'สิบ', 'ร้อย', 'พัน', 'หมื่น', 'แสน', 'ล้าน'];

  function readNumber(numStr) {
    numStr = numStr.replace(/^0+/, '') || '0';
    if (numStr === '0') return '';
    let result = '';
    const len = numStr.length;
    for (let i = 0; i < len; i++) {
      const d = parseInt(numStr[i], 10);
      const pos = len - i - 1; // place index within this group of up to 7 digits
      if (d === 0) continue;
      if (pos === 0 && d === 1 && len > 1) {
        result += 'เอ็ด';
      } else if (pos === 1 && d === 2) {
        result += 'ยี่สิบ';
      } else if (pos === 1 && d === 1) {
        result += 'สิบ';
      } else {
        result += digit[d] + (place[pos] || '');
      }
    }
    return result;
  }

  amount = Math.round(Math.abs(amount) * 100) / 100;
  const parts = amount.toFixed(2).split('.');
  let baht = parts[0];
  let satang = parts[1];
  let text = '';

  if (baht === '0') {
    text += 'ศูนย์บาท';
  } else if (baht.length <= 7) {
    text += readNumber(baht) + 'บาท';
  } else {
    // handle millions for very large numbers (rare for freelance invoices)
    const millionPart = baht.slice(0, baht.length - 6);
    const rest = baht.slice(-6);
    text += readNumber(millionPart) + 'ล้าน' + readNumber(rest) + 'บาท';
  }
  if (satang === '00') {
    text += 'ถ้วน';
  } else {
    text += readNumber(satang) + 'สตางค์';
  }
  return text;
}

/** Exports a specific sheet tab as a PDF Blob (A4, no gridlines). */
function exportSheetAsPdf_(sheet) {
  const ss = SpreadsheetApp.getActiveSpreadsheet();
  const baseUrl = ss.getUrl().replace(/edit(\?.*)?$/, '').replace(/\/$/, '');
  const exportUrl = baseUrl + '/export?format=pdf&size=A4&portrait=true'
    + '&fitw=true&top_margin=0.3&bottom_margin=0.3&left_margin=0.3&right_margin=0.3'
    + '&sheetnames=false&printtitle=false&pagenumbers=false&gridlines=false&fzr=false'
    + '&gid=' + sheet.getSheetId();
  const token = ScriptApp.getOAuthToken();
  const response = UrlFetchApp.fetch(exportUrl, {
    headers: { Authorization: 'Bearer ' + token },
  });
  return response.getBlob();
}

function getOrCreateSubfolder_(parent, name) {
  const it = parent.getFoldersByName(name);
  return it.hasNext() ? it.next() : parent.createFolder(name);
}

/** Finds a row in a log sheet by document number in column A. Returns row index or -1. */
function findLogRow_(sheetName, docNo) {
  const sh = SpreadsheetApp.getActiveSpreadsheet().getSheetByName(sheetName);
  const values = sh.getRange(3, 1, 500, 1).getValues();
  for (let i = 0; i < values.length; i++) {
    if (values[i][0] === docNo) return i + 3;
  }
  return -1;
}

function firstEmptyRow_(sheetName) {
  const sh = SpreadsheetApp.getActiveSpreadsheet().getSheetByName(sheetName);
  const values = sh.getRange(3, 1, 500, 1).getValues();
  for (let i = 0; i < values.length; i++) {
    if (!values[i][0]) return i + 3;
  }
  return 503; // fallback, sheet has 500 pre-formatted rows starting row 3
}

// ------------------------------------------------------------------
// Main generation flow
// ------------------------------------------------------------------
function generateDocument() {
  const ui = SpreadsheetApp.getUi();
  const ss = SpreadsheetApp.getActiveSpreadsheet();
  const nd = ss.getSheetByName(SHEET_NAMES.NEW_DOC);

  const docType = nd.getRange('B4').getValue();
  const clientName = nd.getRange('B5').getValue();
  const refDocNo = nd.getRange('B6').getValue();
  const dueOrValidDate = nd.getRange('B7').getValue();
  const notes = nd.getRange('B8').getValue();
  const paymentMethod = nd.getRange('B9').getValue();
  const paymentRef = nd.getRange('B10').getValue();

  if (!docType) { ui.alert('กรุณาเลือกประเภทเอกสาร'); return; }
  if (!clientName) { ui.alert('กรุณาเลือกลูกค้า'); return; }

  const items = nd.getRange(13, 1, 8, 6).getValues().filter(function (row) {
    return row[1] !== '' && row[1] !== null;
  });
  if (items.length === 0) { ui.alert('กรุณากรอกรายการอย่างน้อย 1 รายการ'); return; }

  const client = findClientRow_(clientName);
  if (!client) { ui.alert('ไม่พบข้อมูลลูกค้า "' + clientName + '" ในชีท Clients'); return; }

  let tplName, logSheetName, color, folderName;
  if (docType === DOC_TYPE.QUOTATION) { tplName = SHEET_NAMES.QUOTATION_TPL; logSheetName = SHEET_NAMES.QUOTATIONS; folderName = 'ใบเสนอราคา'; }
  else if (docType === DOC_TYPE.INVOICE) { tplName = SHEET_NAMES.INVOICE_TPL; logSheetName = SHEET_NAMES.INVOICES; folderName = 'ใบแจ้งหนี้'; }
  else { tplName = SHEET_NAMES.RECEIPT_TPL; logSheetName = SHEET_NAMES.RECEIPTS; folderName = 'ใบเสร็จรับเงิน'; }

  const tpl = ss.getSheetByName(tplName);
  const docNo = nextDocNumber_(docType);
  const today = new Date();

  // --- meta rows ---
  tpl.getRange('B7').setValue(docNo);
  tpl.getRange('B8').setValue(today);

  if (docType === DOC_TYPE.QUOTATION) {
    tpl.getRange('A9').setValue('ยืนราคาถึงวันที่:');
    tpl.getRange('B9').setValue(dueOrValidDate || '');
    tpl.getRange('A10').setValue('');
    tpl.getRange('B10').setValue('');
  } else if (docType === DOC_TYPE.INVOICE) {
    tpl.getRange('A9').setValue('กำหนดชำระเงินภายใน:');
    tpl.getRange('B9').setValue(dueOrValidDate || '');
    tpl.getRange('A10').setValue('อ้างอิงใบเสนอราคา:');
    tpl.getRange('B10').setValue(refDocNo || '-');
  } else {
    tpl.getRange('A9').setValue('อ้างอิงใบแจ้งหนี้:');
    tpl.getRange('B9').setValue(refDocNo || '-');
    tpl.getRange('A10').setValue('');
    tpl.getRange('B10').setValue('');
  }

  // --- client block ---
  tpl.getRange('B13').setValue(client.name);
  tpl.getRange('B14').setValue(client.address);
  tpl.getRange('B15').setValue((client.phone || '') + (client.email ? '  /  ' + client.email : ''));
  tpl.getRange('B16').setValue(client.taxId || '-');

  // --- items (rows 19-26, up to 8) ---
  const itemRange = tpl.getRange(19, 2, 8, 4); // B..E
  itemRange.clearContent();
  for (let i = 0; i < items.length && i < 8; i++) {
    tpl.getRange(19 + i, 2).setValue(items[i][1]); // รายการ
    tpl.getRange(19 + i, 3).setValue(items[i][2]); // จำนวน
    tpl.getRange(19 + i, 4).setValue(items[i][3]); // หน่วย
    tpl.getRange(19 + i, 5).setValue(items[i][4]); // ราคาต่อหน่วย
  }

  // --- notes ---
  tpl.getRange('A31').setValue(notes ? ('หมายเหตุ: ' + notes) : '');

  // --- type-specific extra block ---
  if (docType === DOC_TYPE.RECEIPT) {
    tpl.getRange('B34').setValue(paymentMethod || '-');
    tpl.getRange('B35').setValue(paymentRef || '-');
  }

  SpreadsheetApp.flush();

  const grandTotal = tpl.getRange('F29').getValue();

  if (docType === DOC_TYPE.RECEIPT) {
    tpl.getRange('B36').setValue(bahtText_(grandTotal));
    SpreadsheetApp.flush();
  }

  // --- export PDF ---
  const settings = getSettingsSheet_();
  let rootFolder;
  const rootId = settings.getRange('B22').getValue();
  try {
    rootFolder = rootId ? DriveApp.getFolderById(rootId) : null;
  } catch (e) { rootFolder = null; }
  if (!rootFolder) {
    rootFolder = DriveApp.createFolder('เอกสารธุรกิจ - ' + ss.getName());
    settings.getRange('B22').setValue(rootFolder.getId());
  }
  const subFolder = getOrCreateSubfolder_(rootFolder, folderName);
  const pdfBlob = exportSheetAsPdf_(tpl).setName(docNo + ' - ' + client.name + '.pdf');
  const file = subFolder.createFile(pdfBlob);
  const pdfUrl = file.getUrl();

  // --- log entry ---
  const logRow = firstEmptyRow_(logSheetName);
  const logSheet = ss.getSheetByName(logSheetName);
  if (docType === DOC_TYPE.QUOTATION) {
    logSheet.getRange(logRow, 1, 1, 7).setValues([[docNo, today, client.name, grandTotal, 'ส่งแล้ว', dueOrValidDate || '', pdfUrl]]);
  } else if (docType === DOC_TYPE.INVOICE) {
    logSheet.getRange(logRow, 1, 1, 8).setValues([[docNo, today, client.name, refDocNo || '', dueOrValidDate || '', grandTotal, 'ยังไม่ชำระ', pdfUrl]]);
    if (refDocNo) {
      const qRow = findLogRow_(SHEET_NAMES.QUOTATIONS, refDocNo);
      if (qRow > 0) ss.getSheetByName(SHEET_NAMES.QUOTATIONS).getRange(qRow, 5).setValue('แปลงเป็นใบแจ้งหนี้แล้ว');
    }
  } else {
    logSheet.getRange(logRow, 1, 1, 7).setValues([[docNo, today, client.name, refDocNo || '', grandTotal, paymentMethod || '', pdfUrl]]);
    if (refDocNo) {
      const iRow = findLogRow_(SHEET_NAMES.INVOICES, refDocNo);
      if (iRow > 0) ss.getSheetByName(SHEET_NAMES.INVOICES).getRange(iRow, 7).setValue('ชำระแล้ว');
    }
  }

  // --- clear the New Document form for next entry ---
  nd.getRange('B6').setValue('');
  nd.getRange('B7').setValue('');
  nd.getRange('B8').setValue('');
  nd.getRange('B9').setValue('');
  nd.getRange('B10').setValue('');
  nd.getRange(13, 2, 8, 4).clearContent();

  ui.alert('สร้างเอกสารสำเร็จ: ' + docNo + '\nเปิดดู PDF ได้ที่:\n' + pdfUrl);
}
